# SquadSync - Linux Deployment Guide

Complete guide to deploy SquadSync on a fresh Linux machine.

## 📋 Prerequisites

### System Requirements
- **OS**: Ubuntu 20.04+ / Debian 11+ / CentOS 8+ / Any Linux with Docker support
- **RAM**: Minimum 2GB (4GB recommended)
- **Disk**: At least 5GB free space
- **Network**: Internet connection for downloading Docker images

### Required Software
- Docker Engine 20.10+
- Docker Compose 2.0+

## 🚀 Quick Installation Steps

### Step 1: Install Docker & Docker Compose

#### For Ubuntu/Debian:
```bash
# Update system
sudo apt-get update

# Install Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh

# Add your user to docker group (to run without sudo)
sudo usermod -aG docker $USER

# Install Docker Compose
sudo curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose

# Log out and log back in for group changes to take effect
# Or run: newgrp docker
```

#### For CentOS/RHEL:
```bash
# Install Docker
sudo yum install -y docker
sudo systemctl start docker
sudo systemctl enable docker

# Add user to docker group
sudo usermod -aG docker $USER

# Install Docker Compose
sudo curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose

# Log out and log back in
```

### Step 2: Verify Installation
```bash
# Check Docker version
docker --version

# Check Docker Compose version
docker-compose --version

# Test Docker (should run without errors)
docker run hello-world
```

### Step 3: Transfer Application Files

Copy the entire `squadsync-main` folder to your Linux machine using one of these methods:

**Option A: Using SCP (from another Linux/Mac machine)**
```bash
scp -r squadsync-main user@your-linux-ip:/home/user/
```

**Option B: Using Git (if you have a repository)**
```bash
git clone <your-repo-url>
cd squadsync-main
```

**Option C: Using USB drive or file transfer**
- Copy the folder to USB drive
- Transfer to Linux machine
- Extract if compressed

### Step 4: Navigate to Project Directory
```bash
cd squadsync-main
```

### Step 5: Create Environment File

```bash
# Copy example environment file
cp .env.example .env

# Edit the .env file with your secrets
nano .env
```

**IMPORTANT**: Edit `.env` and change these values:
- `JWT_SECRET_KEY`: Generate a random string (at least 32 characters)
- `JWT_REFRESH_SECRET_KEY`: Generate another random string (at least 32 characters)

**Quick way to generate secrets:**
```bash
# Generate random secrets (run this twice for two different secrets)
openssl rand -hex 32
```

Copy the output and paste into `.env` file.

### Step 6: Build and Start Application

```bash
# Build all Docker images (this may take 5-10 minutes first time)
docker-compose build

# Start all services
docker-compose up -d

# Check if services are running
docker-compose ps
```

You should see 4 services running:
- `postgres`
- `redis`
- `squadsync-backend`
- `frontend`

### Step 7: Initialize Database

```bash
# Run database migrations (creates all tables)
docker-compose exec backend alembic upgrade head
```

### Step 8: Verify Application is Running

```bash
# Check backend health
curl http://localhost:8000/health

# Check backend readiness (should show database and redis as true)
curl http://localhost:8000/ready

# Check frontend (should return HTML)
curl http://localhost:3000
```

### Step 9: Access the Application

Open your web browser and navigate to:
- **Frontend (Main App)**: http://localhost:3000
- **API Documentation**: http://localhost:8000/docs
- **Health Check**: http://localhost:8000/health

## 🎯 First Time Setup

1. **Register a new account** at http://localhost:3000/register
2. **Login** with your credentials
3. **Create squads** and start using the application!

## 📝 Useful Commands

### View Logs
```bash
# All services
docker-compose logs -f

# Specific service
docker-compose logs -f backend
docker-compose logs -f frontend
```

### Stop Application
```bash
docker-compose down
```

### Stop and Remove Volumes (⚠️ Deletes all data)
```bash
docker-compose down -v
```

### Restart Application
```bash
docker-compose restart
```

### Update Application
```bash
# Pull latest code changes
git pull  # or copy new files

# Rebuild and restart
docker-compose up -d --build
```

## 🔧 Troubleshooting

### Port Already in Use
If ports 3000, 8000, 5432, or 6379 are already in use:

Edit `docker-compose.yml` and change the port mappings:
```yaml
ports:
  - "3001:80"  # Change frontend port
  - "8001:8000"  # Change backend port
```

### Docker Permission Denied
```bash
# Add user to docker group
sudo usermod -aG docker $USER

# Log out and log back in, or run:
newgrp docker
```

### Database Connection Error
```bash
# Check if postgres container is healthy
docker-compose ps

# Check postgres logs
docker-compose logs postgres

# Restart postgres
docker-compose restart postgres
```

### Redis Connection Error
```bash
# Check redis logs
docker-compose logs redis

# Restart redis
docker-compose restart redis
```

### Backend Won't Start
```bash
# Check backend logs
docker-compose logs backend

# Common issues:
# 1. Missing .env file
# 2. Invalid JWT_SECRET_KEY (must be 32+ chars)
# 3. Database not ready (wait for postgres health check)
```

### Frontend Shows Connection Error
- Check if backend is running: `curl http://localhost:8000/health`
- Check browser console for errors
- Verify `VITE_API_URL` in docker-compose.yml matches your backend URL

## 🔒 Security Notes

1. **Change default passwords** in production
2. **Use strong JWT secrets** (32+ characters, random)
3. **Don't expose ports** to public internet without firewall
4. **Use HTTPS** in production (set up reverse proxy like Nginx)
5. **Keep Docker updated**: `sudo apt-get update && sudo apt-get upgrade docker-ce`

## 🌐 Accessing from Another Machine

If you want to access the application from another machine on the same network:

1. **Find your Linux machine's IP address:**
   ```bash
   ip addr show
   # Look for inet address (e.g., 192.168.1.100)
   ```

2. **Access from another machine:**
   - Frontend: http://192.168.1.100:3000
   - API: http://192.168.1.100:8000

3. **If firewall blocks access:**
   ```bash
   # Ubuntu/Debian
   sudo ufw allow 3000
   sudo ufw allow 8000
   
   # CentOS/RHEL
   sudo firewall-cmd --add-port=3000/tcp --permanent
   sudo firewall-cmd --add-port=8000/tcp --permanent
   sudo firewall-cmd --reload
   ```

## 📦 Production Deployment

For production deployment:

1. **Set up reverse proxy** (Nginx/Traefik) with SSL
2. **Use environment-specific secrets**
3. **Set up monitoring** (logs, metrics)
4. **Configure backups** for PostgreSQL
5. **Use Docker secrets** instead of .env file
6. **Set up auto-restart** policies

## ✅ Verification Checklist

- [ ] Docker and Docker Compose installed
- [ ] `.env` file created with valid secrets
- [ ] All containers running (`docker-compose ps`)
- [ ] Database migrations completed
- [ ] Health check returns OK (`curl http://localhost:8000/health`)
- [ ] Frontend accessible at http://localhost:3000
- [ ] Can register and login successfully

## 🆘 Need Help?

If you encounter issues:
1. Check logs: `docker-compose logs`
2. Verify all prerequisites are met
3. Ensure `.env` file is correctly configured
4. Check firewall settings
5. Verify Docker has enough resources

---

**Status**: Ready for deployment ✅

For more details, see:
- `README.md` - General project information
- `PRODUCTION_CHECKLIST.md` - Production readiness checklist
