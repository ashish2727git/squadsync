#!/bin/bash

# SquadSync Deployment Script for Linux
# This script automates the deployment process

set -e  # Exit on error

echo "=========================================="
echo "SquadSync Deployment Script"
echo "=========================================="
echo ""

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check if Docker is installed
check_docker() {
    echo -n "Checking Docker installation... "
    if command -v docker &> /dev/null; then
        echo -e "${GREEN}✓${NC}"
        docker --version
    else
        echo -e "${RED}✗${NC}"
        echo "Docker is not installed. Please install Docker first."
        echo "Visit: https://docs.docker.com/get-docker/"
        exit 1
    fi
}

# Check if Docker Compose is installed
check_docker_compose() {
    echo -n "Checking Docker Compose installation... "
    if command -v docker-compose &> /dev/null || docker compose version &> /dev/null; then
        echo -e "${GREEN}✓${NC}"
        docker-compose --version || docker compose version
    else
        echo -e "${RED}✗${NC}"
        echo "Docker Compose is not installed. Please install Docker Compose first."
        exit 1
    fi
}

# Check if .env file exists
check_env_file() {
    echo -n "Checking .env file... "
    if [ -f .env ]; then
        echo -e "${GREEN}✓${NC}"
        
        # Check if JWT_SECRET_KEY is set and valid
        if grep -q "JWT_SECRET_KEY=your-very-long" .env || grep -q "JWT_SECRET_KEY=$" .env; then
            echo -e "${YELLOW}⚠ Warning: JWT_SECRET_KEY appears to be default or empty${NC}"
            echo "Please edit .env file and set a strong secret (32+ characters)"
            read -p "Continue anyway? (y/N): " -n 1 -r
            echo
            if [[ ! $REPLY =~ ^[Yy]$ ]]; then
                exit 1
            fi
        fi
    else
        echo -e "${YELLOW}⚠${NC}"
        echo ".env file not found. Creating from .env.example..."
        if [ -f .env.example ]; then
            cp .env.example .env
            echo -e "${YELLOW}⚠ Please edit .env file and set your secrets before continuing${NC}"
            echo "Press Enter after editing .env file..."
            read
        else
            echo -e "${RED}✗ .env.example not found${NC}"
            exit 1
        fi
    fi
}

# Build Docker images
build_images() {
    echo ""
    echo "Building Docker images..."
    echo "This may take 5-10 minutes on first run..."
    docker-compose build
    echo -e "${GREEN}✓ Build complete${NC}"
}

# Start services
start_services() {
    echo ""
    echo "Starting services..."
    docker-compose up -d
    echo -e "${GREEN}✓ Services started${NC}"
    
    echo ""
    echo "Waiting for services to be healthy..."
    sleep 10
    
    # Check service status
    echo ""
    echo "Service Status:"
    docker-compose ps
}

# Run database migrations
run_migrations() {
    echo ""
    echo "Running database migrations..."
    
    # Wait for backend to be ready
    echo "Waiting for backend to be ready..."
    for i in {1..30}; do
        if docker-compose exec -T backend python -c "import sys; sys.exit(0)" 2>/dev/null; then
            break
        fi
        sleep 2
    done
    
    docker-compose exec -T backend alembic upgrade head
    echo -e "${GREEN}✓ Migrations complete${NC}"
}

# Verify deployment
verify_deployment() {
    echo ""
    echo "Verifying deployment..."
    
    # Check backend health
    echo -n "Backend health check... "
    if curl -s http://localhost:8000/health > /dev/null; then
        echo -e "${GREEN}✓${NC}"
    else
        echo -e "${YELLOW}⚠ Backend not responding yet (may need a few more seconds)${NC}"
    fi
    
    # Check frontend
    echo -n "Frontend check... "
    if curl -s http://localhost:3000 > /dev/null; then
        echo -e "${GREEN}✓${NC}"
    else
        echo -e "${YELLOW}⚠ Frontend not responding yet (may need a few more seconds)${NC}"
    fi
}

# Main deployment flow
main() {
    check_docker
    check_docker_compose
    check_env_file
    
    echo ""
    read -p "Ready to deploy? (y/N): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        echo "Deployment cancelled."
        exit 0
    fi
    
    build_images
    start_services
    run_migrations
    verify_deployment
    
    echo ""
    echo "=========================================="
    echo -e "${GREEN}Deployment Complete!${NC}"
    echo "=========================================="
    echo ""
    echo "Application URLs:"
    echo "  Frontend: http://localhost:3000"
    echo "  API Docs: http://localhost:8000/docs"
    echo "  Health:   http://localhost:8000/health"
    echo ""
    echo "Useful commands:"
    echo "  View logs:    docker-compose logs -f"
    echo "  Stop:         docker-compose down"
    echo "  Restart:      docker-compose restart"
    echo ""
}

# Run main function
main
