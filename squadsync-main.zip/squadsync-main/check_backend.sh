#!/bin/bash

# Quick script to check backend logs and diagnose issues

echo "=========================================="
echo "Backend Diagnostic Script"
echo "=========================================="
echo ""

echo "1. Checking backend container status..."
docker-compose ps backend

echo ""
echo "2. Checking backend logs (last 50 lines)..."
docker-compose logs --tail=50 backend

echo ""
echo "3. Checking if .env file exists..."
if [ -f .env ]; then
    echo "✓ .env file exists"
    echo ""
    echo "Checking critical environment variables..."
    if grep -q "JWT_SECRET_KEY=" .env && ! grep -q "JWT_SECRET_KEY=your-very-long" .env; then
        echo "✓ JWT_SECRET_KEY is set"
    else
        echo "✗ JWT_SECRET_KEY is missing or has default value"
    fi
    
    if grep -q "REDIS_URL=" .env; then
        echo "✓ REDIS_URL is set"
        grep "REDIS_URL=" .env
    else
        echo "⚠ REDIS_URL not in .env (will use docker-compose default)"
    fi
    
    if grep -q "ENVIRONMENT=" .env; then
        echo "✓ ENVIRONMENT is set"
        grep "ENVIRONMENT=" .env
    else
        echo "⚠ ENVIRONMENT not set (will default to development)"
    fi
else
    echo "✗ .env file NOT FOUND!"
    echo "Create it with: cp .env.example .env"
fi

echo ""
echo "4. Testing backend container directly..."
docker-compose exec backend python -c "import os; print('REDIS_URL:', os.getenv('REDIS_URL')); print('JWT_SECRET_KEY:', 'SET' if os.getenv('JWT_SECRET_KEY') else 'NOT SET')" 2>&1 || echo "Container not running or cannot execute"

echo ""
echo "=========================================="
echo "Diagnostic Complete"
echo "=========================================="
