"""
SquadSync Backend Package
"""
