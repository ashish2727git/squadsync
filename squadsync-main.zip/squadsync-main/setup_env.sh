#!/bin/bash

# Automated .env file setup script
# Run this on your Linux machine to create .env file automatically

echo "=========================================="
echo "SquadSync Environment Setup"
echo "=========================================="
echo ""

# Check if .env already exists
if [ -f .env ]; then
    echo "⚠️  .env file already exists!"
    read -p "Overwrite? (y/N): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        echo "Keeping existing .env file"
        exit 0
    fi
fi

# Generate secrets
echo "Generating secure secrets..."
JWT_SECRET=$(openssl rand -hex 32)
JWT_REFRESH_SECRET=$(openssl rand -hex 32)

# Create .env file
cat > .env << EOF
# SquadSync Environment Configuration
# Auto-generated on $(date)

# JWT Secrets (auto-generated)
JWT_SECRET_KEY=${JWT_SECRET}
JWT_REFRESH_SECRET_KEY=${JWT_REFRESH_SECRET}

# Database Configuration
DATABASE_URL=postgresql+asyncpg://postgres:postgres@postgres:5432/squadsync

# Redis Configuration
REDIS_URL=redis://redis:6379/0

# Environment
ENVIRONMENT=production

# Logging
LOG_LEVEL=INFO

# CORS Origins
ALLOWED_ORIGINS=http://localhost:3000,http://localhost:5173
EOF

echo "✅ .env file created successfully!"
echo ""
echo "Generated secrets:"
echo "  JWT_SECRET_KEY: ${JWT_SECRET:0:20}... (32+ chars)"
echo "  JWT_REFRESH_SECRET_KEY: ${JWT_REFRESH_SECRET:0:20}... (32+ chars)"
echo ""
echo "You can now run: docker-compose up -d"
