#!/bin/bash
# Startup script for backend that waits for database and runs migrations
# This script is bulletproof - handles all errors gracefully

echo "=========================================="
echo "SquadSync Backend Startup"
echo "=========================================="

# Function to check database connection
check_database() {
  python3 -c "
import asyncio
import sys
import os
os.environ.setdefault('DATABASE_URL', 'postgresql+asyncpg://postgres:postgres@postgres:5432/squadsync')
try:
    from sqlalchemy.ext.asyncio import create_async_engine
    from backend.core.config import DATABASE_URL
    
    async def check():
        try:
            engine = create_async_engine(DATABASE_URL, pool_pre_ping=True, connect_args={'server_settings': {'jit': 'off'}})
            async with engine.connect() as conn:
                await conn.execute('SELECT 1')
            await engine.dispose()
            return True
        except Exception as e:
            return False
    
    result = asyncio.run(check())
    sys.exit(0 if result else 1)
except Exception:
    sys.exit(1)
" 2>/dev/null
  return $?
}

# Wait for database to be ready (max 90 seconds)
echo "Waiting for database to be ready..."
MAX_ATTEMPTS=45
ATTEMPT=0
DB_READY=0

while [ $ATTEMPT -lt $MAX_ATTEMPTS ]; do
  if check_database; then
    echo "✅ Database is ready!"
    DB_READY=1
    break
  else
    ATTEMPT=$((ATTEMPT + 1))
    if [ $((ATTEMPT % 5)) -eq 0 ]; then
      echo "⏳ Still waiting... (attempt $ATTEMPT/$MAX_ATTEMPTS)"
    fi
    sleep 2
  fi
done

if [ $DB_READY -eq 0 ]; then
  echo "⚠️  Database connection timeout after 90 seconds"
  echo "⚠️  Continuing anyway - server will start but migrations may fail"
fi

# Run database migrations (don't fail if this errors)
echo ""
echo "Running database migrations..."
python3 -m alembic upgrade head 2>&1
MIGRATION_EXIT=$?

if [ $MIGRATION_EXIT -eq 0 ]; then
  echo "✅ Migrations completed successfully"
else
  echo "⚠️  Migration exit code: $MIGRATION_EXIT"
  echo "⚠️  This is OK if:"
  echo "   - Tables already exist"
  echo "   - Database is still initializing"
  echo "   - Migration was already applied"
fi

# Start the server (this should never fail to start, even if DB/Redis have issues)
echo ""
echo "Starting backend server..."
echo "=========================================="
echo ""

# Use exec to replace shell process with uvicorn
exec python3 -m uvicorn backend.main:app --host 0.0.0.0 --port 8000 --log-level info
